# Arduino_SK6812
Arduino library for SK6812 based 4-channel RGBW LEDs

## Usage
1. Download repository as .zip file
2. In Arduino IDE: Sketch -> Include Library -> Add .ZIP Library
3. Include the library in your project using "#include <SK6812.h>" directive

## Example
```
#include <EdSoft_SK6812.h>

EdSoft_SK6812 LED(4, 5);       // EdSoft_SK6812LED(NUM_LEDS, LED_PIN);

uint32_t color1 = 0X000000FF;             // 0xWWRRGGBB  

void setup() {
  
  LED.fill(color1, 1, 5 );                //Fill LEDs 2,3 and 4 with color1 LED.fill(RGBWColor, FirstLed, NoofLEDs );
}

void loop() {
  
  LED.setPixelColor(0, {0, 0, 0, 255});     // Set second LED to white (using only W channel)
  LED.show();                               // Send the values to the LEDs
  delay(500);
  
  LED.setPixelColor(0, 0X00FF00FF); // Set second LED to white (using only RGB channels)
  LED.show();
  delay(500);
}




